
public class XuLy {

	public XuLy() {
		// TODO Auto-generated constructor stub
	}

	
	
	public static void main(String[] args) {
		
		int x = 20;
		int y = 29; 
		int kQua = tinhTong(x, y);
		System.out.println("Ket qua la: " + kQua);

	}
	
	public static int tinhTong(int a, int b) {
		int tong = a + b;
		return tong;
	}

}
